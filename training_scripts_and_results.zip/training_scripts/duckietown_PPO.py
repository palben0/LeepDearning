from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import VecFrameStack, SubprocVecEnv, DummyVecEnv, VecMonitor
from stable_baselines3.common.env_util import make_vec_env, make_atari_env
from stable_baselines3 import PPO, A2C, DQN


import gym
import numpy as np
from gym import spaces
from gym_duckietown.envs import DuckietownEnv   # kell a gymnek talan
from gym.wrappers import ResizeObservation, NormalizeObservation

# GLOBAL VARIABLES
SETTINGS = {
    "env_name" : 'Duckietown-udem1-v0',
    "n_envs" : 2,   #4
    "n_stack" : 5,
    "total_timesteps" : 1_500_000,  #25000
    "project" : "duckietown",
    "model_type" : PPO,
    "policy_type" : "CnnPolicy"
}
# Env names
# Duckietown-straight_road-v0
# Duckietown-4way-v0
# Duckietown-udem1-v0
# Duckietown-small_loop-v0
# Duckietown-small_loop_cw-v0
# Duckietown-zigzag_dists-v0
# Duckietown-loop_obstacles-v0 (static obstacles in the road)
# Duckietown-loop_pedestrians-v0 (moving obstacles in the road)
# MultiMap-v0 (wrapper cycling through all maps)


class DiscreteWrapper(gym.ActionWrapper):
    """
    Duckietown environment with discrete actions (left, right, forward)
    instead of continuous control
    """


def custom_wrapper(env, shape):
    env = ResizeObservation(env, shape)
    env = NormalizeObservation(env)
    return env


# CREATE GYM
env = make_vec_env(SETTINGS["env_name"], n_envs=SETTINGS["n_envs"], wrapper_class=
    custom_wrapper, wrapper_kwargs={"shape":(60, 80)})
env = VecFrameStack(env, n_stack=SETTINGS["n_stack"])

# env = VecMonitor(env, filename=f"monitor/{run.id}")
# env = VecVideoRecorder(env, filename=f"video/{run.id}")

# LEARNING
model = SETTINGS["model_type"](
    SETTINGS["policy_type"], env, verbose=1, tensorboard_log="./dqn_tdk", device="auto",
    learning_rate=5e-5, normalize_advantage=True)

model.learn(total_timesteps=SETTINGS["total_timesteps"])
model.save("dqn_tdk_1")
