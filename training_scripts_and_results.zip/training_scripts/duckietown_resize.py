from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import VecFrameStack, SubprocVecEnv, DummyVecEnv, VecMonitor
from stable_baselines3.common.env_util import make_vec_env, make_atari_env
from stable_baselines3 import PPO


import gym
from gym_duckietown.envs import DuckietownEnv   # kell a gymnek talan
from gym.wrappers import ResizeObservation, NormalizeObservation

# GLOBAL VARIABLES
SETTINGS = {
    "env_name" : 'Duckietown-small_loop-v0',
    "n_envs" : 4,   #4
    "n_stack" : 5,
    "total_timesteps" : 25000,  #25000
    "project" : "duckietown",
    "model_type" : PPO,
    "policy_type" : "CnnPolicy"
}
# Env names
# Duckietown-straight_road-v0
# Duckietown-4way-v0
# Duckietown-udem1-v0
# Duckietown-small_loop-v0
# Duckietown-small_loop_cw-v0
# Duckietown-zigzag_dists-v0
# Duckietown-loop_obstacles-v0 (static obstacles in the road)
# Duckietown-loop_pedestrians-v0 (moving obstacles in the road)
# MultiMap-v0 (wrapper cycling through all maps)

def custom_wrapper(env, shape):
    env = ResizeObservation(env, shape=(60,80))
    env = NormalizeObservation(env)
    return env


# CREATE GYM
env = make_vec_env(SETTINGS["env_name"], n_envs=SETTINGS["n_envs"], wrapper_class=
    custom_wrapper, wrapper_kwargs={"shape":(80, 60)})
print(env.observation_space)
env = VecFrameStack(env, n_stack=SETTINGS["n_stack"])

